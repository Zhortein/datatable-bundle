<?php

/*
 * This file was taken and MODIFIED from Twig : https://github.com/twigphp/twig
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed in the same folder as this piece of code.
 */

namespace FriendsOfTwig\Twigcs\TwigPort;

class Token
{
    public const EOF_TYPE = -1;
    public const TEXT_TYPE = 0;
    public const BLOCK_START_TYPE = 1;
    public const VAR_START_TYPE = 2;
    public const BLOCK_END_TYPE = 3;
    public const VAR_END_TYPE = 4;
    public const NAME_TYPE = 5;
    public const NUMBER_TYPE = 6;
    public const STRING_TYPE = 7;
    public const OPERATOR_TYPE = 8;
    public const PUNCTUATION_TYPE = 9;
    public const INTERPOLATION_START_TYPE = 10;
    public const INTERPOLATION_END_TYPE = 11;
    public const ARROW_TYPE = 12;
    public const WHITESPACE_TYPE = 13;
    public const NEWLINE_TYPE = 14;
    public const COMMENT_TYPE = 15;
    private $value;
    private int $type;
    private int $lineno;
    private int $columnno;

    public function __construct(int $type, $value, int $lineno, int $columnno)
    {
        $this->type = $type;
        $this->value = $value;
        $this->lineno = $lineno;
        $this->columnno = $columnno;
    }

    public function __toString()
    {
        return sprintf('%s(%s)', self::typeToString($this->type, true), $this->value);
    }

    public function test($type, $values = null): bool
    {
        if (null === $values && !\is_int($type)) {
            $values = $type;
            $type = self::NAME_TYPE;
        }

        return ($this->type === $type) && (
            null === $values
            || (\is_array($values) && \in_array($this->value, $values, true))
            || $this->value === $values
        );
    }

    public function getLine(): int
    {
        return $this->lineno;
    }

    public function getColumn(): int
    {
        return $this->columnno;
    }

    public function getType(): int
    {
        return $this->type;
    }

    public function getValue()
    {
        return $this->value;
    }

    public static function typeToString(int $type, bool $short = false): string
    {
        switch ($type) {
            case self::EOF_TYPE:
                $name = 'EOF_TYPE';

                break;

            case self::TEXT_TYPE:
                $name = 'TEXT_TYPE';

                break;

            case self::BLOCK_START_TYPE:
                $name = 'BLOCK_START_TYPE';

                break;

            case self::VAR_START_TYPE:
                $name = 'VAR_START_TYPE';

                break;

            case self::BLOCK_END_TYPE:
                $name = 'BLOCK_END_TYPE';

                break;

            case self::VAR_END_TYPE:
                $name = 'VAR_END_TYPE';

                break;

            case self::NAME_TYPE:
                $name = 'NAME_TYPE';

                break;

            case self::NUMBER_TYPE:
                $name = 'NUMBER_TYPE';

                break;

            case self::STRING_TYPE:
                $name = 'STRING_TYPE';

                break;

            case self::OPERATOR_TYPE:
                $name = 'OPERATOR_TYPE';

                break;

            case self::PUNCTUATION_TYPE:
                $name = 'PUNCTUATION_TYPE';

                break;

            case self::INTERPOLATION_START_TYPE:
                $name = 'INTERPOLATION_START_TYPE';

                break;

            case self::INTERPOLATION_END_TYPE:
                $name = 'INTERPOLATION_END_TYPE';

                break;

            case self::ARROW_TYPE:
                $name = 'ARROW_TYPE';

                break;

            case self::WHITESPACE_TYPE:
                $name = 'WHITESPACE_TYPE';

                break;

            case self::NEWLINE_TYPE:
                $name = 'NEWLINE_TYPE';

                break;

            case self::COMMENT_TYPE:
                $name = 'COMMENT_TYPE';

                break;

            default:
                throw new \LogicException(sprintf('Token of type "%s" does not exist.', $type));
        }

        return $short ? $name : 'FriendsOfTwig\Twigcs\TwigPort\Token::'.$name;
    }

    public static function typeToEnglish(int $type): string
    {
        switch ($type) {
            case self::EOF_TYPE:
                return 'end of template';

            case self::TEXT_TYPE:
                return 'text';

            case self::BLOCK_START_TYPE:
                return 'begin of statement block';

            case self::VAR_START_TYPE:
                return 'begin of print statement';

            case self::BLOCK_END_TYPE:
                return 'end of statement block';

            case self::VAR_END_TYPE:
                return 'end of print statement';

            case self::NAME_TYPE:
                return 'name';

            case self::NUMBER_TYPE:
                return 'number';

            case self::STRING_TYPE:
                return 'string';

            case self::OPERATOR_TYPE:
                return 'operator';

            case self::PUNCTUATION_TYPE:
                return 'punctuation';

            case self::INTERPOLATION_START_TYPE:
                return 'begin of string interpolation';

            case self::INTERPOLATION_END_TYPE:
                return 'end of string interpolation';

            case self::ARROW_TYPE:
                return 'arrow function';

            case self::WHITESPACE_TYPE:
                return 'whitespace';

            case self::NEWLINE_TYPE:
                return 'new line';

            case self::COMMENT_TYPE:
                return 'comment';

            default:
                throw new \LogicException(sprintf('Token of type "%s" does not exist.', $type));
        }
    }
}
